package ISP;

public interface Eater {
    void eat();
}
