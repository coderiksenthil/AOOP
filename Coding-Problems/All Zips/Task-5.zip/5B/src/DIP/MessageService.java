package DIP;

public interface MessageService {
    void sendMessage(String message);
}
