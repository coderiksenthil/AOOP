public class Goblin extends Enemy {
    @Override
    public String attack() {
        return "Goblin attacks with a club!";
    }
}