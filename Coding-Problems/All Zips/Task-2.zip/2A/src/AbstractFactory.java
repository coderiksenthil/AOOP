
// Abstract Factory for Weapons and PowerUps
public interface AbstractFactory {
    Weapon createWeapon();
    PowerUp createPowerUp();
}