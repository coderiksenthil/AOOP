public abstract class Enemy {
    public abstract String attack();
}
