
public class Orc extends Enemy {
    @Override
    public String attack() {
        return "Orc attacks with a sword!";
    }
}