public class Potion implements PowerUp {
    @Override
    public String activate() {
        return "Potion activated!";
    }
}
