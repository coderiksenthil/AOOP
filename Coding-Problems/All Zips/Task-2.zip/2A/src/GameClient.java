
// Client code example
public class GameClient {
    public static void main(String[] args) {
        // Singleton
        GameState gameState = GameState.getInstance();
        System.out.println(gameState);

        // Factory Method
        EnemyFactory enemyFactory = new GoblinFactory();
        Enemy enemy = enemyFactory.createEnemy();
        System.out.println(enemy.attack());

        // Abstract Factory
        AbstractFactory factory = new MedievalFactory();
        Weapon weapon = factory.createWeapon();
        PowerUp powerUp = factory.createPowerUp();
        System.out.println(weapon.use());
        System.out.println(powerUp.activate());
    }
}