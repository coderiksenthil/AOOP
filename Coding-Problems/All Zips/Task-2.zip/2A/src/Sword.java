// Concrete Weapon and PowerUp classes
public class Sword implements Weapon {
    @Override
    public String use() {
        return "Swinging a sword!";
    }
}