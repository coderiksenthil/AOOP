
public interface PowerUp {
    String activate();
}