// Concrete Factory for medieval items
public class MedievalFactory implements AbstractFactory {
    @Override
    public Weapon createWeapon() {
        return new Sword();
    }

    @Override
    public PowerUp createPowerUp() {
        return new Potion();
    }
}