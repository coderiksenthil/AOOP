public interface Weapon {
    String use();
}