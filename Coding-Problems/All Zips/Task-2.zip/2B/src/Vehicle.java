
public interface Vehicle {
    String getType();
}
