// MusicSource.java
public interface MusicSource {
    void play();
    void stop();
}
